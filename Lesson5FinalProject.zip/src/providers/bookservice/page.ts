export class page {
  pgNbr: number;
  pgText: string;
}