import { page } from "./page"

export class chapter {
    nbr: number;
    title: string;
    pages: page[] = [];
}